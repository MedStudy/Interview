USE [TestApplication]
GO
/****** Object:  User [TestUser]    Script Date: 11/21/2022 9:48:35 AM ******/
CREATE USER [TestUser] FOR LOGIN [TestUser] WITH DEFAULT_SCHEMA=[dbo]
GO
/****** Object:  Table [dbo].[Customers]    Script Date: 11/21/2022 9:48:35 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Customers](
	[CustomerId] [int] IDENTITY(1,1) NOT NULL,
	[FirstName] [varchar](255) NOT NULL,
	[LastName] [varchar](255) NOT NULL,
	[StateCode] [varchar](2) NOT NULL,
	[Year] [int] NOT NULL,
	[CreatedBy] [int] NOT NULL,
	[CreatedOn] [datetime] NOT NULL,
	[UpdatedBy] [int] NULL,
	[UpdatedOn] [datetime] NULL,
	[DeletedBy] [int] NULL,
	[DeletedOn] [datetime] NULL,
 CONSTRAINT [PK_Customers] PRIMARY KEY CLUSTERED 
(
	[CustomerId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[Customers] ON 
GO
INSERT [dbo].[Customers] ([CustomerId], [FirstName], [LastName], [StateCode], [Year], [CreatedBy], [CreatedOn], [UpdatedBy], [UpdatedOn], [DeletedBy], [DeletedOn]) VALUES (1, N'John', N'Doe', N'AL', 2015, 1, CAST(N'2022-11-19T19:13:08.660' AS DateTime), NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[Customers] ([CustomerId], [FirstName], [LastName], [StateCode], [Year], [CreatedBy], [CreatedOn], [UpdatedBy], [UpdatedOn], [DeletedBy], [DeletedOn]) VALUES (3, N'Smith', N'White', N'FL', 2019, 1, CAST(N'2022-11-19T19:14:14.780' AS DateTime), NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[Customers] ([CustomerId], [FirstName], [LastName], [StateCode], [Year], [CreatedBy], [CreatedOn], [UpdatedBy], [UpdatedOn], [DeletedBy], [DeletedOn]) VALUES (4, N'William', N'Walsh', N'CA', 2021, 1, CAST(N'2022-11-19T19:14:14.780' AS DateTime), NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[Customers] ([CustomerId], [FirstName], [LastName], [StateCode], [Year], [CreatedBy], [CreatedOn], [UpdatedBy], [UpdatedOn], [DeletedBy], [DeletedOn]) VALUES (5, N'Mathew', N'Willson', N'CA', 2022, 1, CAST(N'2022-11-19T19:14:14.780' AS DateTime), NULL, NULL, NULL, NULL)
GO
INSERT [dbo].[Customers] ([CustomerId], [FirstName], [LastName], [StateCode], [Year], [CreatedBy], [CreatedOn], [UpdatedBy], [UpdatedOn], [DeletedBy], [DeletedOn]) VALUES (6, N'Gaby', N'Nicholson', N'GA', 2020, 1, CAST(N'2022-11-19T19:14:14.780' AS DateTime), NULL, NULL, NULL, NULL)
GO
SET IDENTITY_INSERT [dbo].[Customers] OFF
GO
ALTER TABLE [dbo].[Customers] ADD  CONSTRAINT [DF_Customers_CreatedOn]  DEFAULT (getdate()) FOR [CreatedOn]
GO
/****** Object:  StoredProcedure [dbo].[SearchCustomers]    Script Date: 11/21/2022 9:48:35 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Mikin Oza
-- Create date: 11/19/2022
-- Description:	Returns list of customers
-- =============================================
-- Exec [dbo].[SearchCustomers] 
CREATE PROCEDURE [dbo].[SearchCustomers] 
	@firstName VARCHAR(255) = NULL,
	@lastName VARCHAR(255) = NULL,
	@stateCode VARCHAR(2) = NULL,
	@year INT = NULL,
	@page INT = 1,
	@pageSize INT = 50
AS
BEGIN
	
	SET NOCOUNT ON;

	DECLARE @paggingOffSet INT
	SET @paggingOffSet = @pageSize * (@page - 1)

    SELECT	c.CustomerId,
			c.FirstName,
			c.LastName,
			c.[Year],
			c.StateCode,
			c.CreatedOn,
			COUNT(*) OVER () as TotalCount
	FROM	dbo.Customers c
	WHERE	(@firstName IS NULL OR c.FirstName Like '%'+ @firstName +'%')
			AND (@lastName IS NULL OR c.LastName Like '%'+ @lastName +'%')
			AND (@stateCode IS NULL OR c.StateCode = @stateCode)
			AND (@year IS NULL OR c.[Year] = @year)
			AND C.DeletedOn IS NULL
	ORDER BY c.CreatedOn DESC
	OFFSET @paggingOffSet ROWS
	FETCH NEXT @pageSize ROWS ONLY OPTION (RECOMPILE);
END
GO
