﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestApplication.Models.Customers;

namespace TestApplicaton.Business.Interfaces
{
    public interface ICustomerManager
    {
        Task<IEnumerable<Customers>> SearchCustomers(SearchCustomer search);
    }
}
