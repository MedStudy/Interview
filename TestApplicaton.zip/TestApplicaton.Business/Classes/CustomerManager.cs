﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestApplication.DAL.Interfaces;
using TestApplication.Models.Customers;
using TestApplicaton.Business.Interfaces;

namespace TestApplicaton.Business.Classes
{
    public class CustomerManager : ICustomerManager
    {
        private readonly ICustomerRepository _customerRepository;

        public CustomerManager(ICustomerRepository customerRepository)
        {
            this._customerRepository = customerRepository;
        }

        public async Task<IEnumerable<Customers>> SearchCustomers(SearchCustomer search)
        { 
            return await _customerRepository.SearchCustomers(search);
        }
    }
}
