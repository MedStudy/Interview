﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestApplication.DAL.Extensions;
using TestApplicaton.Business.Classes;
using TestApplicaton.Business.Interfaces;

namespace TestApplicaton.Business.Extensions
{
    public static class ServiceCollectionExtensions
    {
        public static void AddBusinessLayerServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddScoped<ICustomerManager, CustomerManager>();
            services.AddDataLayerServices(configuration);
        }
    }
}
