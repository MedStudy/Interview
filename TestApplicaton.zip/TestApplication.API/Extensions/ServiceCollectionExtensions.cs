﻿using TestApplicaton.Business.Extensions;

namespace TestApplication.API.Extensions
{
    public static class ServiceCollectionExtensions
    {
        public static void AddPresentationLayerService(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddBusinessLayerServices(configuration);
        }
    }
}
