﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TestApplication.Models.Customers;
using TestApplicaton.Business.Interfaces;

namespace TestApplication.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        private readonly ICustomerManager _customerManager;

        public CustomerController(ICustomerManager customerManager)
            : base()
        {
            this._customerManager = customerManager;
        }

        [HttpPost]
        [Route("searchCustomers")]
        public async Task<IActionResult> SearchCustomers(SearchCustomer search)
        {
            var customers = await this._customerManager.SearchCustomers(search);
            return Ok(customers);
        }
    }
}
