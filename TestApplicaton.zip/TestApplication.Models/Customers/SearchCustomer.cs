﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApplication.Models.Customers
{
    public class SearchCustomer : Customers
    {
        public int PageSize { get; set; }
        public int Page { get; set; }
    }
}
