﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApplication.Models.Settings
{
    public class RepositoryBaseSettings
    {
        public string Primary { get; set; } = null!;
    }
}
