﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApplication.DAL.Interfaces
{
    public interface IRepositoryBase
    {
        Task<List<TClass>> GetListFromProcedureAsync<TClass>(string procedureName, SqlParameter[]? parameters) where TClass : class, new();
    }
}
