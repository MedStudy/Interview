﻿using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestApplication.DAL.Interfaces;
using TestApplication.Models.Customers;
using TestApplication.Models.Settings;

namespace TestApplication.DAL.Classes
{
    public class CustomerRepository : RepositoryBase, ICustomerRepository
    {
        public CustomerRepository(IOptions<RepositoryBaseSettings> options) : base(options)
        {
        }

        public async Task<IEnumerable<Customers>> SearchCustomers(SearchCustomer search)
        {
            SqlParameter[] parameters =
                {
                        new SqlParameter("@firstName",search.FirstName),
                        new SqlParameter("@lastName",search.LastName),
                        new SqlParameter("@stateCode",search.StateCode),
                        new SqlParameter("@year",search.Year),
                        new SqlParameter("@page",search.Page),
                        new SqlParameter("@pageSize",search.PageSize)
                };
            return await this.GetListFromProcedureAsync<Customers>("[dbo].[SearchCustomers]", parameters);
        }
    }
}
