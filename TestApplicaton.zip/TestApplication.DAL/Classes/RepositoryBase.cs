﻿using Microsoft.Extensions.Options;
using System.Data;
using System.Data.SqlClient;
using TestApplication.DAL.Extensions;
using TestApplication.DAL.Interfaces;
using TestApplication.Models.Settings;

namespace TestApplication.DAL.Classes
{
    public class RepositoryBase : IRepositoryBase
    {
        private readonly string _connectionString;

        public RepositoryBase(IOptions<RepositoryBaseSettings> options)
        {
            _connectionString = options.Value.Primary;
        }

        public async Task<List<TClass>> GetListFromProcedureAsync<TClass>(string procedureName, SqlParameter[]? parameters) where TClass : class, new()
        {
            await using var cnx = new SqlConnection(_connectionString);
            await using var cmd = new SqlCommand
            {
                Connection = cnx,
                CommandType = CommandType.StoredProcedure,
                CommandText = procedureName,
            };

            if (parameters != null && parameters.Length > 0)
                cmd.Parameters.AddRange(parameters);

            await cnx.OpenAsync();
            await using var reader = cmd.ExecuteReaderAsync().Result;
            return reader.ToList<TClass>();
        }

    }
}

