﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestApplication.DAL.Classes;
using TestApplication.DAL.Interfaces;
using TestApplication.Models.Settings;

namespace TestApplication.DAL.Extensions
{
    public static class ServiceCollectionExtensions
    {
        public static void AddDataLayerServices(this IServiceCollection services, IConfiguration configuration)
        {
            var repositoryBaseSettings = configuration.GetSection("ConnectionStrings");
            services.Configure<RepositoryBaseSettings>(repositoryBaseSettings);

            services.AddScoped<ICustomerRepository, CustomerRepository>();
        }
    }
}
