﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace TestApplication.DAL.Extensions
{
    public static class DataReaderExtensions
    {
        private static Func<T> GetInstanceCreator<T>(IDataReader reader) where T : class, new()
        {
            var instanceType = typeof(T);

            var propertyBinders = new List<Action<T>>(); // methods which set an instance property to a column value

            var fields = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase); // field name lookup

            for (int i = 0, ln = reader.FieldCount; i < ln; i++)
            {
                fields[reader.GetName(i)] = i;
            }

            // enumerate instance properties
            foreach (var prop in instanceType.GetProperties(BindingFlags.Instance | BindingFlags.Public))
            {
                if (prop.SetMethod == null) continue; // if we can't set the property, skip it

                int fieldIndex;

                // try to find a matching field name
                if (fields.TryGetValue(prop.Name, out fieldIndex))
                {
                    var propType = Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType;
                    var fieldType = reader.GetFieldType(fieldIndex);

                    if (propType.Equals(fieldType)) // exact match
                    {
                        propertyBinders.Add((instance) =>
                        {
                            if (!reader.IsDBNull(fieldIndex))
                            {
                                prop.SetValue(instance, reader.GetValue(fieldIndex));
                            }
                        });
                    }
                    else if (propType.IsEnum) // special case for enums
                    {
                        var underlyingEnumType = Enum.GetUnderlyingType(propType);

                        if (underlyingEnumType.Equals(fieldType)) // underlying enum type matches
                        {
                            propertyBinders.Add((instance) =>
                            {
                                if (!reader.IsDBNull(fieldIndex))
                                {
                                    prop.SetValue(instance, Enum.ToObject(propType, reader.GetValue(fieldIndex)));
                                }
                            });
                        }
                        else // underlying enum type mismatch; attempt to convert
                        {
                            propertyBinders.Add((instance) =>
                            {
                                if (!reader.IsDBNull(fieldIndex))
                                {
                                    try
                                    {
                                        prop.SetValue(instance, Enum.ToObject(propType, Convert.ChangeType(reader.GetValue(fieldIndex), underlyingEnumType, CultureInfo.InvariantCulture)));
                                    }
                                    catch { }
                                }
                            });
                        }
                    }
                    else // type mismatch; attempt to convert
                    {
                        propertyBinders.Add((instance) =>
                        {
                            if (!reader.IsDBNull(fieldIndex))
                            {
                                try
                                {
                                    prop.SetValue(instance, Convert.ChangeType(reader.GetValue(fieldIndex), propType, CultureInfo.InvariantCulture));
                                }
                                catch { }
                            }
                        });
                    }
                }
            }

            // return a function which will create, populate, and return an instance of T
            return () =>
            {
                // create an instance of T
                T instance = new T();

                // apply values from datareader
                foreach (var bindProperty in propertyBinders)
                {
                    bindProperty(instance);
                }

                // return populated instance
                return instance;
            };
        }

        public static List<T> ToList<T>(this IDataReader reader) where T : class, new()
        {
            var list = new List<T>();
            if (reader.Read())
            {
                // get a method for creating a class instance from each record
                var createInstance = GetInstanceCreator<T>(reader);

                // create an instance for each record
                do
                {
                    list.Add(createInstance());
                }
                while (reader.Read());
            }

            reader.NextResult();
            return list;
        }
    }
}
