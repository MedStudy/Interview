import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { CustomerModel } from '../../models/customer.model';
import { SearchCustomerModel } from '../../models/search-customer.model';
import { CustomerService } from '../../services/customer.service';

@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.css']
})
export class CustomersComponent implements OnInit {

  searchCustomerForm!: FormGroup;
  stateList: any[] = [] as any[];
  customers: CustomerModel[] = [] as CustomerModel[];
  years: number[] = [] as number[];

  tableData = {
    moduleHeader: ["First Name", "Last Name", "State", "Year", "Created On", ""]
  }
  pagCount: number = 1;
  defaultPage: number = 1;
  defaultPageSize: number = 2;
  totalCount: number = 0;
  range: number[] = [0, 0] as number[];

  constructor(private fb: FormBuilder, private apiService: CustomerService) { }

  ngOnInit(): void {    

    this.bindDropdown();

    this.searchCustomerForm = this.fb.group({
      firstName: [null],
      lastName: [null],
      stateCode: [null],
      year: [null],
      page: [null],
      pageSize: [null]
    });

    this.setPage();
    this.onSearchCustomers(this.searchCustomerForm.value);   
  }

  bindDropdown() {
    this.apiService.getStates().subscribe((res) => {
      this.stateList = res as any[];
    });

    var year = new Date().getFullYear();
    this.years.push(year);
    for (var i = 1; i < 25; i++) {
      this.years.push(year - i);
    }
  }

  setPage() {
    this.searchCustomerForm.get('page')?.setValue(this.defaultPage);
    this.searchCustomerForm.get('pageSize')?.setValue(this.defaultPageSize);
  }

  onSearchCustomers(searchData: any) {
    this.apiService.searchCustomers(searchData).subscribe(res => {
      var customerList = res as CustomerModel[];
      customerList.forEach(obj => {
        var state = this.stateList.find(_obj => _obj["value"] == obj.stateCode);
        if (state) {
          obj.state = state["name"];
        }
      });
      this.customers = customerList;

      var searchCustomer = this.searchCustomerForm.value as SearchCustomerModel;
      var pageSize = searchCustomer.pageSize;
      var pageNumber = searchCustomer.page;

      this.totalCount = this.customers[0].totalCount;
      this.pagCount = this.totalCount < pageSize ? 1 : Math.ceil(this.totalCount / pageSize);

      this.range = [((pageNumber - 1) * pageSize) + 1, Math.min(pageNumber * pageSize, this.totalCount)]
      
    });
  }

  onReset() {
    this.searchCustomerForm.reset();
    this.setPage();
    this.onSearchCustomers(this.searchCustomerForm.value);
  }

  next() {
    var searchCustomer = this.searchCustomerForm.value as SearchCustomerModel;
    if (searchCustomer.page <= this.pagCount) {
      searchCustomer.page++;
      this.onSearchCustomers(this.searchCustomerForm.value);
    }
  }

  back() {
    var searchCustomer = this.searchCustomerForm.value as SearchCustomerModel;
    if (searchCustomer.page > 1)
      searchCustomer.page--;
    this.onSearchCustomers(this.searchCustomerForm.value);
  }
}

