import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SharedService {
  public loader: BehaviorSubject<boolean> = new BehaviorSubject(false);
  public globalErrorMessage: BehaviorSubject<string> = new BehaviorSubject("");
  public loaderCount: number = 0;

  constructor() {
  }

  showLoader() {
    this.loaderCount++;
    this.loader.next(true);
  }

  hideLoader() {
    this.loaderCount--;
    if (this.loaderCount <= 0) {
      this.loader.next(false);
    }
  }

  showGlobalErrorMessage(message: string) {
    this.globalErrorMessage.next(message);
  }

  hideGlobalErrorMessage() {
    this.globalErrorMessage.next('');
  }
}
