import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { SharedService } from '../shared/shared.service';

@Injectable({
  providedIn: 'root'
})
export class ApiClientService {

  private headerOptions: HttpHeaders = {} as HttpHeaders;

  constructor(private http: HttpClient, private router: Router,
    private sharedService: SharedService) {
    
  }

  public getStaticData(url: string) {
    return this.http.get(url);
  }
    
  public post(url: string, data: any, header: any = undefined, showLoading: boolean = true) {
    if (showLoading) {
      this.sharedService.showLoader();
    }
    return this.http.post(this.fullUrl(url), data, { headers: header ? header : this.headerOptions })
      .pipe(
        map(response => {
          if (showLoading) {
            this.sharedService.hideLoader();
          }
          return response;
        }),
        catchError((err) => { if (showLoading) { this.hideLoader(); } return this.handleError(err); })
      );
  }

  private fullUrl(url: string): string {
    return environment.apiBaseURL + url;
  }

  private hideLoader() {
    this.sharedService.hideLoader();
  }

  private handleError(response: any) {
    var error = {
      status: response.status,
      message: ''
    };
    if (response.status === 401) {
      this.headerOptions = {} as HttpHeaders;
    }
    else if (response.error) {
      if (response.error.status) {
        error.status = response.error.status;
      }

      if (typeof "" == typeof response.error) {
        error.message = response.error;
      }
      else {
        error.message = response.message ? response.message : response.error.error_description;
      }

    }
    else {
      error.message = response.message;
    }
    return throwError(() => new Error(error.message));
  }
}

