import { Injectable } from '@angular/core';
import { SearchCustomerModel } from '../models/search-customer.model';
import { ApiClientService } from './api-client.service';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  constructor(private apiClient: ApiClientService) {
      }

  public searchCustomers(search: SearchCustomerModel, showLoading: boolean = true) {
    return this.apiClient.post("customer/searchCustomers", search, undefined, showLoading);
  }

  public getStates() {
    return this.apiClient.getStaticData("../../assets/json/states.json");
  }
}
