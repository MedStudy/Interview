
export interface CustomerModel {
  firstName: string,
  lastName: string,
  stateCode: string,
  state: string,
  year: number,
  createdOn: Date,
  totalCount: number
}
