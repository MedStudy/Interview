import { CustomerModel } from "./customer.model";

export interface SearchCustomerModel extends CustomerModel {
  page: number,
  pageSize: number
}
